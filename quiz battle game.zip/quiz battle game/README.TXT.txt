Quiz Battle Game
Welcome to Quiz Battle Arena! This isn't just another quiz app; it's your personal battlefield for knowledge. Built with Java Swing and powered by MySQL, it’s where you can test your wits, challenge yourself, and see how you stack up against others. Ready to claim the top spot on the leaderboard?
What Makes It Cool?
Your Personal Account: Sign up, log in, and keep all your achievements in one place.
Pick Your Poison: Choose from a variety of subjects like Java, C++, and Python. What's your specialty?
Brain Teasers: Dive into multiple-choice questions designed to make you think.
For the Glory: Every quiz ends with a score. Will you make it to the Hall of Fame?
Behind the Curtain: An admin panel lets authorized users keep the question bank fresh and challenging.
The Techy Stuff
The Brain (Backend): Java (JDK 24)
The Face (Frontend): Swing for a clean, classic GUI
The Memory (Database): MySQL
The Messenger (Connectivity): JDBC Driver
The Workshop (IDE): IntelliJ IDEA
QuizBattleGame

src/db Package

Contains DBConnection.java which handles all database connectivity
Acts as the bridge between the Java application and MySQL database
Manages connection pooling and SQL query execution

src/model Package (Data Blueprints)

User.java: Defines user attributes like username, email, and registration date
Question.java: Structures quiz questions with options and correct answers
Subject.java: Represents different quiz categories/topics
Score.java: Tracks user performance and quiz results

src/ui Package (User Interface Screens)

LoginScreen.java: Handles user authentication and registration
QuizScreen.java: Main interface where users answer questions
ResultScreen.java: Displays scores and performance feedback
LeaderboardScreen.java: Shows ranking of top performers
AdminPanel.java: Administrative interface for managing content
QuestionForm.java: Form for adding/editing quiz questions

Main.java

Application entry point
Initializes the program and loads the first screen
Manages overall application flow
Set Up The Project
Open IntelliJ IDEA.
Click on Open and select the project folder you downloaded.

Add the MySQL Connector:

Download the mysql-connector-j-9.3.0.jar file.
In IntelliJ, go to File > Project Structure > Libraries.
Click the + button, select Java, and find the downloaded JAR file.
Click OK to add it.

Connect to Your Database:

Find the DBConnection.java file in the db package.
Update the connection string, username, and password to match your local MySQL setup.
How to Play
Start Your Journey: Launch the app and either create a new account or log in.
Choose Your Battlefield: Select a subject that interests you.
Enter the Arena: Answer the questions as they appear. The clock is ticking!
Claim Your Reward: After the final question, see your score and review what you got right and wrong.
Climb the Ladder: Check the leaderboard to see if you've made it to the top!